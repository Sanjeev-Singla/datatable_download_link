$(document).ready(function(){
	$.noConflict();
	$('table#example').DataTable();
});